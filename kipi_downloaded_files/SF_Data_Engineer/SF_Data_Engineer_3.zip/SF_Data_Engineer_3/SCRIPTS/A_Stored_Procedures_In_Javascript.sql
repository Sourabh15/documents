USE ROLE SYSADMIN;
USE SCHEMA MRF_DB.HR_SCHEMA;

CREATE OR REPLACE PROCEDURE delete_emp(LNAME string)
RETURNS STRING NOT NULL
LANGUAGE javascript
AS
$$


// lot of validations can be done before delete the employee
// prepare the SQL String
var cmd = "DELETE FROM EMP_BASIC_INGEST WHERE LAST_NAME=" + "'"+ LNAME + "'"

// pass the SQL Statement String to the "SNOWFLAKE" Object "Create Statement" method.
var stmt = snowflake.createStatement({sqlText: cmd});

// execute SQL Statement
var result = stmt.execute();

return 'success';

$$;

-- Calling the stored procedures using CALL statement
CALL delete_emp('Anneslie');

------------------------------------------
--Sample-02 :  Read the employee details 
-------------------------------------------

CREATE OR REPLACE PROCEDURE read_emp()
RETURNS VARCHAR NOT NULL
LANGUAGE JAVASCRIPT
AS
$$

	var return_value = "";
    // prepare the SQL String    
	var cmd = "SELECT * FROM EMP_BASIC_INGEST LIMIT 2;"
    
    // pass the SQL Statement String to the "SNOWFLAKE" Object "Create Statement" method.
	var stmt = snowflake.createStatement( {sqlText: cmd } );
    
    // execute SQL Statement
	var rs = stmt.execute();
	
    //Since Table rows cannot be returned, concatenate all the column values and return the scalar value
    while (rs.next())  {
        return_value += "\n";
        return_value += rs.getColumnValue(1);
        return_value += ", " + rs.getColumnValue(2);
        return_value += ", " + rs.getColumnValue(3);
        return_value += ", " + rs.getColumnValue(4);
        return_value += ", " + rs.getColumnValue(5);
        }
    return return_value;
  $$ ;
  
CALL read_emp();

-----------------------------------------------------
-- Sample-03 : Catching an Error using Try/Catch
-------------------------------------------------------
  
CREATE OR REPLACE PROCEDURE validate_age (age float)
RETURNS VARCHAR
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS $$
    try {
        if (AGE < 0) {
            throw "Age cannot be negative!";
        } else {
            return "Age validated.";
        }
    } catch (err) {
        return "Error: " + err;
    }
    $$
   ;

CALL validate_age(-2);

------------------------------------
-- --Sample-04:GET ROW COUNT PROCEDURE
--------------------------------

CREATE OR REPLACE PROCEDURE get_row_count(table_name VARCHAR)
RETURNS FLOAT NOT NULL
LANGUAGE javascript
AS
  $$
  var row_count = 0;
  // Dynamically compose the SQL statement to execute.
  var sql_command = "select count(*) from " + TABLE_NAME;
  // Run the statement.
  var stmt = snowflake.createStatement(
         {
         sqlText: sql_command
         }
      );
  var res = stmt.execute();
  // Get back the row count. Specifically, ...
  // ... get the first (and in this case only) row from the result set ...
  res.next();
  // ... and then get the returned value, which in this case is the number of
  // rows in the table.
  row_count = res.getColumnValue(1);
  return row_count;
  $$
  ;
 
 CALL get_row_count('emp_basic_ingest');
 ----------------------------------------------
----Sample-05:Transaction using procdure 
------------------------------------------
CREATE OR REPLACE TABLE EMPLOYEE_T ( emp_id integer);

CREATE OR REPLACE PROCEDURE tran_sample()
RETURNS VARCHAR
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS $$
try{
    snowflake.execute (
        {sqlText: "begin transaction;"}
        );
        
    snowflake.execute (
        {sqlText: "insert into EMPLOYEE_T (emp_id) values (1);"}
        );     
        
        
    snowflake.execute (
        {sqlText: "insert into EMPLOYEE_T (emp_id) values (2);"}
        );              
        
    snowflake.execute (
        {sqlText: "commit;"}
        );        
    return_value = 'success';        
      
}
catch(err)
{
    snowflake.execute (
        {sqlText: "rollback;"}
        );    
      return_value = 'failed';
}
          
return  return_value;   
$$;
    

CALL tran_sample();

SELECT * FROM EMPLOYEE_T;



