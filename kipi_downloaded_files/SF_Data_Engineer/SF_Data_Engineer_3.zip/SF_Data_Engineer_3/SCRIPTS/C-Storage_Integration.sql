CREATE OR REPLACE STORAGE INTEGRATION S3_role_integration
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE
  STORAGE_AWS_ROLE_ARN = "arn:aws:iam::756826086051:role/snowflake_role"
  STORAGE_ALLOWED_LOCATIONS = ("s3://sara-sf-training/");


DESC INTEGRATION S3_role_integration;

--update external id and principal in the AWS trusted policy

grant create stage on schema public to role sysadmin;

grant usage on integration S3_role_integration to role sysadmin;

  create or replace stage S3_stage
  url = ('s3://sara-sf-training/')
  storage_integration = S3_role_integration;
  
  list @S3_stage;
  --------------------------------------------------
  
  
create or replace api integration my_api_integration_obj
  api_provider = aws_api_gateway
  api_aws_role_arn = 'arn:aws:iam::756826086051:role/snowflake-lambda-role'
  api_allowed_prefixes = ('https://9oqblx7k2e.execute-api.ap-southeast-1.amazonaws.com/test/snowflake-proxy')
  enabled = true;
  
  DESC INTEGRATION MY_API_INTEGRATION_OBJ ;
  
  create external function my_external_function(n integer, v varchar)
    returns variant
    api_integration = my_api_integration_obj
    as 'https://9oqblx7k2e.execute-api.ap-southeast-1.amazonaws.com/test/snowflake-proxy';
  
 --Table Creation
 create or replace table test_data (id integer,name varchar);
 -- Row Insertion
 insert into test_data values(10100561,'Sri');
 insert into test_data values(10100562,'Sara');
  
 SELECT my_external_function (id,name) from test_data;
 

  
  
