--Exercise-2 Load data From Aws--------------------------------------------------------------
use schema mrf_db.sales_schema;
use warehouse compute_wh;

CREATE OR REPLACE TABLE TRIPS  
(tripduration integer,
  starttime timestamp,
  stoptime timestamp,
  start_station_id integer,
  start_station_name string,
  start_station_latitude float,
  start_station_longitude float,
  end_station_id integer,
  end_station_name string,
  end_station_latitude float,
  end_station_longitude float,
  bikeid integer,
  membership_type string,
  usertype string,
  birth_year integer,
  gender integer);
  
 
CREATE OR REPLACE FILE FORMAT "TRIPS_FILE_CSV"
TYPE = 'CSV' 
COMPRESSION = 'AUTO' 
FIELD_DELIMITER = ',' 
RECORD_DELIMITER = '\n' 
SKIP_HEADER = 0 
FIELD_OPTIONALLY_ENCLOSED_BY = '\042' 
TRIM_SPACE = FALSE 
ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE 
ESCAPE = 'NONE' 
ESCAPE_UNENCLOSED_FIELD = '\134' 
DATE_FORMAT = 'AUTO' 
TIMESTAMP_FORMAT = 'AUTO' 
NULL_IF = ('');

 --URL s3://snowflake-workshop-lab/citibike-trips
CREATE OR REPLACE STAGE TRIPS_EXT_STAGE 
URL = 's3://snowflake-workshop-lab/citibike-trips';

COPY INTO trips FROM @TRIPS_EXT_STAGE
file_format='TRIPS_FILE_CSV'
pattern='.*trips.*[.]csv.gz'
on_error = 'skip_file' ;