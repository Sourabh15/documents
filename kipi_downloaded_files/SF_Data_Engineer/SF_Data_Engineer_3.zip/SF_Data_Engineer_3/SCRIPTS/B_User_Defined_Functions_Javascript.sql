USE DATABASE MRF_DB;
CREATE SCHEMA TRAINING;
USE SCHEMA TRAINING;
-----------------------------------------SCALAR JAVASCRIPT -------------------------------

--create a very simple UDF that squares the value that is provided as the input. we must capitalize the parameter name when used in the function definition. This can be seen in the code below, where the input parameter val was used in the uppercase and used as VAL.
CREATE OR REPLACE FUNCTION square(val float)
RETURNS float
LANGUAGE JAVASCRIPT  
AS
  'return VAL * VAL;'
;

--test this function by calling it in a SELECT statement
SELECT square(11115);
--The statement will output the value 25 as expected. 

--create a recursive JavaScript UDF. We will be creating a simple factorial function which will recursively call itself to calculate factorial of the input value.
CREATE FUNCTION factorial(val float)
RETURNS float
LANGUAGE JAVASCRIPT  
AS
$$
    if ( VAL == 1 ){
        return VAL;
    }
    else{
        return VAL * factorial(VAL -1);
    }
$$
;

--try out the factorial function by invoking the function in a select statement, as shown as follows.
SELECT factorial(5);


-----------------------------------------SCALAR SQL -------------------------------

--create a quite simple UDF that squares the value that is provided as the input.
CREATE FUNCTION sql_square(val float)
RETURNS float
AS
$$
  val * val
$$
;

--test this function by calling it in a SELECT statement. 
SELECT sql_square(5);


--create a slightly more complicated function that can apply a tax percentage (10% in this case) and return us the profit after tax deduction. 
CREATE OR REPLACE FUNCTION profit_after_tax(cost float, revenue float)
RETURNS float
AS
$$
  (revenue - cost) * (1 - 0.1)
$$
;

--call the function with a simple SELECT statement
SELECT profit_after_tax(100,120);

--call this UDF in the SELECT list as well as the WHERE clause.
SELECT DD.D_DATE, SUM(profit_after_tax(SS_WHOLESALE_COST,SS_SALES_PRICE)) AS real_profit 
FROM SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.STORE_SALES SS 
INNER JOIN SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.DATE_DIM DD
ON SS.SS_SOLD_DATE_SK = DD.D_DATE_SK
WHERE DD.D_DATE BETWEEN '2003-01-01' AND '2003-12-31' 
AND profit_after_tax(SS_WHOLESALE_COST,SS_SALES_PRICE) < -50
GROUP BY DD.D_DATE;



---------3. TABULAR FUNCTION USING JAVASCRIPT----------------




--run an out of the box table function provided by Snowflake to see how to call table functions and review the results returned by that function. The function that we are going to use is used for generating rows of random data and is a handy function for various scenario. The function is aptly called GENERATOR. Let us call this function to generate 10 rows of data. To do so run the command below.
SELECT seq4() AS incremental_id, random() AS a_random_number
FROM TABLE(generator(rowcount => 10));

--create a quite simple table function using JavaScript. The function will return the 2 letter ISO code for a country. To keep things simple, we will use hard coded values for this initial example.  Run the following SQL to create this function.
CREATE FUNCTION CountryISO()
RETURNS TABLE(CountryCode String, CountryName String)
LANGUAGE JAVASCRIPT
AS
$$
   {
   processRow: function f(row, rowWriter, context){
       rowWriter.writeRow({COUNTRYCODE: "AU",COUNTRYNAME: "Australia"});
       rowWriter.writeRow({COUNTRYCODE: "NZ",COUNTRYNAME: "New Zealand"});   
       rowWriter.writeRow({COUNTRYCODE: "PK",COUNTRYNAME: "Pakistan"});   
       }
    }    
$$;

--call this function.
SELECT * FROM TABLE(CountryISO());

--you can treat this output as any other relational table, so you can add where clauses and select only particular columns.
SELECT COUNTRYCODE FROM TABLE(CountryISO()) WHERE CountryCode = 'PK';

--We do not have to hardcode values in a table function but rather we can select data from existing table and process on each row. Let’s create such a java script-based table function which processes on values for each row of a table produces the count of character for the input.
CREATE FUNCTION StringSize(input String)
RETURNS TABLE (Size FLOAT)
LANGUAGE JAVASCRIPT
AS 
$$
{
    processRow: function f(row, rowWriter, context) {
      rowWriter.writeRow({SIZE: row.INPUT.length});
    }
}
$$;

--call this function to review the output. Now, we can call this function for a single value but that is not very useful, however, let’s call for a single value to demonstrate the concept.
SELECT * FROM TABLE(StringSize('TEST'));

--you can join this newly created table function with another table and have the table function process multiple rows. 
SELECT * FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.NATION, TABLE(StringSize(N_NAME));

---------4. TABULAR FUNCTION USING JAVASCRIPT----------------


--run an out of the box table function provided by Snowflake to see how to call table functions
SELECT *
FROM TABLE(information_schema.query_history_by_session())
ORDER BY start_time;

 
--create a quite simple table function using SQL. The function will return the name of a location and the time zone that the location has. To keep things simple, we will use hard coded values. 
CREATE FUNCTION LocationTimeZone()
RETURNS TABLE(LocationName String, TimeZoneName String)
as
$$
    SELECT 'Sydney', 'GMT+11'
    UNION
    SELECT 'Auckland', 'GMT+13'
    UNION
    SELECT 'Islamabad', 'GMT+5'
    UNION
    SELECT 'London', 'GMT'
$$;

--call this function.
SELECT * FROM TABLE(LocationTimeZone());

 --you can treat this output as any other relational table, so you can add where clauses and select only particular columns. To do so run the following SQL:
SELECT TimeZoneName FROM TABLE(LocationTimeZone())
WHERE LocationName = 'Sydney';

--We do not have to hardcode values in a table function but rather we can select from existing tables and even join tables with-in our function definition. Let’s create such a table function which joins data from two table to produce an output.
CREATE OR REPLACE FUNCTION CustomerOrders()
RETURNS TABLE(CustomerName String, TotalSpent Number(12,2))
as
$$
    SELECT C.C_NAME AS CustomerName, SUM(O.O_TOTALPRICE) AS TotalSpent
    FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS O 
    INNER JOIN SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.CUSTOMER C
    ON C.C_CUSTKEY = O.O_CUSTKEY
    GROUP BY C.C_NAME
$$;

--call this function to review the output. 
SELECT * FROM TABLE(CustomerOrders());


--alter the function so that it can take customer name as a parameter. 
CREATE FUNCTION CustomerOrders(CustomerName String)
RETURNS TABLE(CustomerName String, TotalSpent Number(12,2))
as
$$
    SELECT C.C_NAME AS CustomerName, SUM(O.O_TOTALPRICE) AS TotalSpent
    FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS O 
    INNER JOIN SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.CUSTOMER C
    ON C.C_CUSTKEY = O.O_CUSTKEY
    WHERE C.C_NAME = CustomerName
    GROUP BY C.C_NAME
$$;

--it is important to understand that we have created two functions here. One function called CustomerOrders that does not take any parameter and another with the same name that accepts the name as a parameter. To demonstrate this run the following SQL.
SHOW FUNCTIONS LIKE '%CustomerOrders%';


--Let us now call the new function by passing in a customer name as a paramter.
SELECT * FROM TABLE(CustomerOrders('Customer#000062993'));