-- Using UI Orgadmin role, create new account in the different cloud provider and its region using Orgadmin role  

-- Assume the ORGADMIN role
use role orgadmin;

-- View the list of the accounts
show organization accounts;


create account mrf_mumbai
  admin_name = sara
  admin_password = 'Snowflake123*'
  first_name = sara
  last_name = shan
  email = 'snowflake.aug16@gmail.com'
  edition = enterprise
  region = AWS_AP_SOUTH_1;
  
ALTER ACCOUNT mrf_mumbai RENAME TO mrf_uswest;

ALTER ACCOUNT YN67592 RENAME TO mrf_singapore;

use role accountadmin;

ALTER ACCOUNT YN67592 RENAME TO mrf_singapore;

show organization accounts;

-- Enable replication for an primary account "YN67592"
select system$global_account_set_parameter('JN65038','ENABLE_ACCOUNT_DATABASE_REPLICATION', 'true');

-- Enable replication for the secondary account
select system$global_account_set_parameter('GEA29513','ENABLE_ACCOUNT_DATABASE_REPLICATION', 'true');


use role accountadmin;
--promoting the demo_db as primary database Note: Provide secondary account name instead of account_locator
ALTER DATABASE "MRF_DB" ENABLE REPLICATION TO ACCOUNTS "XCWIBET"."MRF_USWEST";

show replication databases;

-----------------------
secondary account scripts
-------------------------

--login into secondary account in separate window

use role accountadmin;
-- creating secondary database 
CREATE DATABASE "MRF_DB_SECONDARY" AS REPLICA OF "XCWIBET"."JN65038"."MRF_DB";
ALTER DATABASE "MRF_DB_SECONDARY" REFRESH;

-- Promote a secondary database to serve as the primary database.
alter database "MRF_DB_SECONDARY" primary;

-- Verify that the former secondary database was promoted successfully.
show replication databases;

DELETE FROM "MRF_DB_SECONDARY"."SALES_SCHEMA"."CUSTOMER" WHERE FIRSTNAME = 'Maria'