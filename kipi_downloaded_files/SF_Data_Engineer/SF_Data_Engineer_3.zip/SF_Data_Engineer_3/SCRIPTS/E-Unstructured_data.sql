use role SYSADMIN;

use mrf_db;

create schema MRF_DB.IMAGES_SCHEMA;

use MRF_DB.IMAGES_SCHEMA;

create or replace stage int_flower_images directory = ( enable = true);

-- Upload the data files in to internal stage using PUT command

-- put file://C:\Data\Flower_Images\5-Tulip\*.jpg @int_flower_images auto_compress = false;

list @int_flower_images/Tulip;

-------------------- External Stage------------

create or replace stage ext_flower_images url= 's3://sara-sf-training/flower_images/' 
credentials=(aws_key_id='AKIA3ANSZTKRXPACT46V' aws_secret_key='9ALJwiSiYnXXQPflSAUfTKqSynh2NGGPEHRbI3hw')
directory = ( enable = true auto_refresh =  true);

list @ext_flower_images/5-Tulip;

use role accountadmin;
create or replace role image_reader_role ;
grant role image_reader_role to user sara;
grant all on database mrf_db to role image_reader_role;
grant all on schema mrf_db.images_schema to role image_reader_role;
use role sysadmin;


--unstructured data governance
grant read on stage int_flower_images to role image_reader_role;

use role image_reader_role;
list @int_flower_images/Tulip;
remove  @int_flower_images/Tulip;
use role sysadmin;

-- #3 scoped URLis nothing view on top of unstructured data for providing access to subset of file
-- #4 access unstructured data with rest_api. access the files from their applications

-- presigned url- authentication already built-into-the URL
use role accountadmin;
select get_presigned_url(@ext_flower_images,'5-Tulip/4300258119_b03f2f956e.jpg' );

--staged url, contains schema details, No built in authentication. get authentication first and then call this url
select build_stage_file_url(@ext_flower_images,'5-Tulip/4300258119_b03f2f956e.jpg');

-- build scoped url - it hides the database schema information

select build_scoped_file_url(@ext_flower_images,'5-Tulip/4300258119_b03f2f956e.jpg');


create or replace view scoped_files_view as 
select build_scoped_file_url(@ext_flower_images,'5-Tulip/4300258119_b03f2f956e.jpg') as scoped_url;

grant select on scoped_files_view to role image_reader_role;

use role image_reader_role;
-- you will not be able to access complete document folder
list @ext_flower_images;
-- you will be to access the scoped_files_view
--you can also create as secured view and share it with other accounts
select * from scoped_files_view;
-- 
use role sysadmin;

-- #4 unstructured data using directory tables.
-- if the number of files are more in the stage then it helps to query file names, modified date using filter
-- streams on directory table

list @ext_flower_images;

select count(*) from directory(@ext_flower_images) ; --275

select count(*) from directory(@ext_flower_images) where file_url like '%Tulip%' ; --52

create stream ext_flower_images_stream on directory(@ext_flower_images);

DESC STAGE ext_flower_images;

select * from ext_flower_images_stream;

--# process unstructured data with UDF with Java

--# process unstructured data with external functions.





