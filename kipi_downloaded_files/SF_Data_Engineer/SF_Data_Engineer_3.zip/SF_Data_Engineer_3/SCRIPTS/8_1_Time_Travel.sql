use role sysadmin;
use schema MRF_DB.SALES_SCHEMA;
use warehouse MRF_SALES_WH;


---Scenario-1 : Dropping the table by mistake
drop table customer;
--Check if the table exists
Select * from customer limit 10;
-- Using TIME TRAVEL, we can UNDROP the table
undrop table customer;

---Scenario-2 : Roll back the update example

update customer set CITY = 'Chennai';
--Check if the update affected all the rows
Select * from customer limit 20;

set query_id = 
(select query_id from 
table(information_schema.query_history_by_session (result_limit=>5)) 
where query_text like 'update%' order by start_time limit 1);


-- Find the query id from the HISTORY Screen and replace
select * from customer before (statement => $query_id) limit 20;
-- recreate the table
create or replace table customer as
(select * from customer before (statement => $query_id));
-- Check the table whether all the records restored        
Select * from customer limit 20;

