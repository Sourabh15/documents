--SNOW PIPE DEMO STEPS

--1. create s3 bucket(s3://sara-sf-training/employee/) with default options
--2. create an user (mysnowpipe02-user)
--3. create a policy (mysnowpipe02-policy) attached to s3 bucket with read and list permission
--4. edit the policy and update the json with content recommended by snowflake
--5. attach the user mysnowpipe02-user to the policy(mysnowpipe-policy)

-- TASKS IN SNOWFLAKE

--6. login to snowflake and create a table emp_basic_ingest(Staging Table)

--7. create a file format (CSV)

--8. create an AWS external stage (AWS_SNOWPIPE_STAGE) pointing mysnowpipe02 s3 bucket

--9. create a snowpipe object (EMP_SNOWPIPE) and copy the notification id

--10 Create stream object

--11 create final table

--12 create task object

--in AWS S3, go to mysnowpipe02 bucket properties and create even notification(mysnowpipe02-event), 
--then select SQS and enter enter the notification id(which u got it from snowflake snowpipe object)

--upload a file in s3 bucket and after a minute these files gets parsed and copied into staging table;


USE ROLE sysadmin;
USE SCHEMA MRF_DB.HR_SCHEMA;

--step 6: creating the ingest table(Staging Table)
CREATE OR REPLACE TABLE EMP_BASIC_INGEST
(
FIRST_NAME STRING,
LAST_NAME STRING,
EMAIL STRING,
STREETADDRESS STRING,
CITY STRING,
START_DATE DATE
);

--step 7: File Format
CREATE OR REPLACE FILE FORMAT EMP_CSV TYPE = 'CSV' COMPRESSION = 'AUTO' 
FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' SKIP_HEADER = 0 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' 
TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE ESCAPE = 'NONE' 
ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N');

--step 8: creating the AWS stage
CREATE OR REPLACE STAGE AWS_EMP_SNOWPIPE_STAGE 
URL = 's3://sara-sf-training/employee/' 
CREDENTIALS = (AWS_KEY_ID = 'AKIA3ANSZTKR55JOT4H5' 
               AWS_SECRET_KEY = 'nCEI/uu0IH807UvlCTaQVl211G3V56GUFJQVredv');
  
-- list command will list down all the stage files from s3 bucket
LIST @AWS_EMP_SNOWPIPE_STAGE;

REMOVE @AWS_EMP_SNOWPIPE_STAGE;

-- step 9: snowpipe object
CREATE OR REPLACE PIPE EMP_SNOWPIPE auto_ingest=true as
COPY INTO EMP_BASIC_INGEST
FROM @AWS_EMP_SNOWPIPE_STAGE
FILE_FORMAT = EMP_CSV;

-- list down the snowpipe objects
SHOW PIPES;

-- Create event notification in AWS
--arn:aws:sqs:ap-south-1:053974605456:sf-snowpipe-AIDAQZEJDD2INOI7MAH6E-ALlOfojkWuFg5GYbJqfv3g

-- COPY FILES INTO AWS

--This table function can be used to validate data files processed by Snowpipe within a specified time range. 
--The function returns details about any errors encountered during an attempted data load into Snowflake tables.
SELECT * FROM TABLE(validate_pipe_load( pipe_name=>'MRF_DB.HR_SCHEMA.EMP_SNOWPIPE',  start_time=>dateadd(hour, -1, current_timestamp())));


--This table function can be used to query Snowflake data loading history along various dimensions within the last 14 days. 
--The function returns load activity for both COPY INTO <table> statements and continuous data loading using Snowpipe. 
SELECT * FROM TABLE(information_schema.copy_history(table_name=>'EMP_BASIC_INGEST', start_time=> dateadd(hours, -1, current_timestamp())));

--This table function can be used to query the history of data loaded into Snowflake tables using Snowpipe within a specified date range. 
--The function returns the history of data loaded and credits billed for your entire Snowflake account.
SELECT * FROM TABLE(information_schema.pipe_usage_history(date_range_start=> dateadd(hours, -1, current_timestamp()),pipe_name=>'EMP_SNOWPIPE'));
  
--Retrieves a JSON representation of the current status of a pipe
SELECT SYSTEM$PIPE_STATUS('EMP_SNOWPIPE' );

-- PAUSE AND RESTART THE PIPE
--ALTER PIPE EMP_SNOWPIPE SET pipe_execution_paused = true;
--ALTER PIPE EMP_SNOWPIPE SET pipe_execution_paused = false;
--ALTER PIPE EMP_SNOWPIPE refresh;

-- verify whether the records got inserted
SELECT * from EMP_BASIC_INGEST;



