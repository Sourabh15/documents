use role sysadmin;
use SCHEMA MRF_DB.HR_SCHEMA;

-- -- step 9: Create Stream attached to the ingest table

CREATE OR REPLACE STREAM emp_basic_stream on table emp_basic_ingest  APPEND_ONLY = FALSE;

-- -- step 9: Create Stream attached to the ingest table
SELECT * from EMP_BASIC_STREAM;

SELECT * FROM emp_basic_ingest;

SELECT * from EMP_BASIC_STREAM;

--Final table
CREATE OR REPLACE TABLE emp_basic
(
	name string,
	email string,
	streetaddress string,
	city string,
	start_date date
);

-- Create Tasks attached to the Stream

CREATE or REPLACE TASK emp_basic_task WAREHOUSE = MRF_HR_WH SCHEDULE = '1 minute'
WHEN
  SYSTEM$STREAM_HAS_DATA('emp_basic_stream')
AS
  INSERT INTO emp_basic (name ,email ,streetaddress ,city ,start_date)
  SELECT CONCAT(LAST_NAME,' , ',FIRST_NAME) ,email ,streetaddress ,city ,start_date 
  FROM emp_basic_stream WHERE METADATA$ACTION = 'INSERT';
  
-- grant execute task privilege to sysadmin.otherwise task will not get executed
use role accountadmin;
grant execute task on account to role sysadmin;
use role sysadmin;

-- to view the current taks
show tasks;

-- check whether records inserted into stream table
select * from emp_basic_stream;

-- check whether records inserted into final table
select * from emp_basic;


-- if the task is in suspended mode, then resume it manually 
ALTER TASK emp_basic_task RESUME;

-- Check whether tasks has got executed or not from task history
select * from table(information_schema.task_history()) order by scheduled_time desc;


-- drop the task otherwise it keeps running in the server which incur cost
--Drop task emp_basic_task;
