use role sysadmin;
use schema MRF_DB.SALES_SCHEMA;

-- Create Table with Sales Person and Region details
create or replace table customers_rls
( cust_id number,cust_name varchar, 
  cust_cntry varchar, 
  cust_region varchar, 
  cust_state varchar
);
                                      
-- Inserting sample records                                      
insert into customers_rls values (1, 'Venkat','India','South','AP');
insert into customers_rls values (6, 'Krishna','India','South','AP');
insert into customers_rls values (2, 'Rajesh','India','South','TL');
insert into customers_rls values (3, 'Ravi','India','South','KA');
insert into customers_rls values (4, 'Rahul','India','North','UP');
insert into customers_rls values (5, 'Rakesh','India','North','MP');

-- Create Mapping Table with Regional and Role Mapping
create or replace table config_rls_mapping
( role_name varchar, 
  c_region varchar, 
  cust_state varchar
);

-- Inserting mapping records
insert into config_rls_mapping values ('REGION_SOUTH','South','');
insert into config_rls_mapping values ('REGION_NORTH','North','');

grant select on table config_rls_mapping to role accountadmin;

--select * from customers_rls;
--Create roles

use role accountadmin;

create role REGION_SOUTH;
create role REGION_NORTH;

grant role region_south to user sara;
grant role region_north to user sara;

use role sysadmin;

grant usage on database MRF_DB to role REGION_NORTH;
grant usage on database MRF_DB to role REGION_SOUTH;

grant usage on schema SALES_SCHEMA TO ROLE REGION_NORTH;
grant usage on schema SALES_SCHEMA TO ROLE REGION_SOUTH;

grant usage on warehouse MRF_SALES_WH to role REGION_SOUTH;
grant usage on warehouse MRF_SALES_WH to role REGION_NORTH;

grant select on table customers_rls to role REGION_SOUTH;
grant select on table config_rls_mapping to role REGION_SOUTH;
grant select on table customers_rls to role REGION_NORTH;
grant select on table config_rls_mapping to role REGION_NORTH;
grant select on table customers_rls to role SYSADMIN;
grant select on table config_rls_mapping to role SYSADMIN;


use role accountadmin;

create or replace row access policy new_sales_policy as (cust_region varchar) returns boolean ->
  'SYSADMIN' = current_role()
   or exists (
              select 1 from config_rls_mapping
              where role_name = current_role()
              and c_region = cust_region
              );

grant apply on row access policy new_sales_policy to role REGION_SOUTH;
grant apply on row access policy new_sales_policy to role REGION_NORTH;

alter table CUSTOMERS_RLS add row access policy new_sales_policy on (cust_region);


use role REGION_SOUTH;
select * from customers_rls;
use role REGION_NORTH;
select * from customers_rls;
use role SYSADMIN;
select * from customers_rls;


