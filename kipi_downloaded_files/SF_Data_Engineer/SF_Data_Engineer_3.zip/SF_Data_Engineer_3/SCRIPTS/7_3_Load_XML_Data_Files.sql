// XML DDL Scripts
USE ROLE SYSADMIN;
USE SCHEMA MRF_DB.TRAINING_SCHEMA;

// Create an Ingestion Table for XML Data
CREATE OR REPLACE TABLE AUTHOR_INGEST_XML
(
  "RAW_AUTHOR" VARIANT
);

//Create File Format for XML Data
CREATE OR REPLACE FILE FORMAT XML_FILE_FORMAT 
TYPE = 'XML' 
COMPRESSION = 'AUTO' 
PRESERVE_SPACE = FALSE 
STRIP_OUTER_ELEMENT = TRUE 
DISABLE_SNOWFLAKE_DATA = FALSE 
DISABLE_AUTO_CONVERT = FALSE 
IGNORE_UTF8_ERRORS = FALSE; 

CREATE OR REPLACE STAGE AWS_SEMISTRUCTURED_STAGE   
url='s3://sara-sf-training/northwind/semistructured/'
credentials=(aws_key_id='AKIA3ANSZTKRXPACT46V' aws_secret_key='9ALJwiSiYnXXQPflSAUfTKqSynh2NGGPEHRbI3hw');

list @AWS_SEMISTRUCTURED_STAGE;

COPY INTO AUTHOR_INGEST_XML FROM @AWS_SEMISTRUCTURED_STAGE
FILE_FORMAT = 'XML_FILE_FORMAT'
pattern='.*author.*[.]xml';

SELECT * FROM AUTHOR_INGEST_XML;

-- Load author_with_header.xml using load "table wizard"

//add ::STRING to cast the values into strings and get rid of the quotes
SELECT 
raw_author:"@AUTHOR_UID" as AUTHOR_ID
,XMLGET(raw_author, 'FIRST_NAME'):"$"::STRING as FIRST_NAME
,XMLGET(raw_author, 'MIDDLE_NAME'):"$"::STRING as MIDDLE_NAME
,XMLGET(raw_author, 'LAST_NAME'):"$"::STRING as LAST_NAME
FROM AUTHOR_INGEST_XML;

