USE ROLE sysadmin;
USE DATABASE MRF_DB;
USE SCHEMA MRF_DB.SALES_SCHEMA;

/*==============================================================*/
/* Table: Customer                                              */
/*==============================================================*/
create or replace table Customer (
   Id                   number                  identity,
   FirstName            varchar(40)         not null,
   LastName             varchar(40)         not null,
   City                 varchar(40)         null,
   Country              varchar(40)         null,
   Phone                varchar(20)         null
);

/*==============================================================*/
/* Table: Orders                                               */
/*==============================================================*/
create or replace table Orders (
   Id                   number                  identity,
   OrderNumber          varchar(10)             null,
   CustomerId           number                  not null,
   TotalAmount          float                   null default 0,
   OrderDate            varchar(40)             not null
);


/*==============================================================*/
/* Table: OrderItem                                             */
/*==============================================================*/
create or replace table OrderItem (
   Id                   number                  identity,
   OrderId              number                  not null,
   ProductId            number                  not null,
   UnitPrice            float                   not null default 0,
   Quantity             number                  not null default 1
);


/*==============================================================*/
/* Table: Product                                               */
/*==============================================================*/
create or replace table Product (
   Id                   number                  identity,
   ProductName          varchar(50)             not null,
   SupplierId           number                  not null,
   UnitPrice            float                   null default 0,
   Package              varchar(30)             null,
   IsDiscontinued       boolean                 not null
);

/*==============================================================*/
/* Table: Supplier                                              */
/*==============================================================*/
create or replace table Supplier (
   Id                   number              identity,
   CompanyName          varchar(40)         not null,
   ContactName          varchar(50)         null,
   ContactTitle         varchar(40)         null,
   City                 varchar(40)         null,
   Country              varchar(40)         null,
   Phone                varchar(30)         null,
   Fax                  varchar(30)         null
);



--File Format 
CREATE OR REPLACE FILE FORMAT MRF_CSV TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = ',' RECORD_DELIMITER = '\n' 
SKIP_HEADER = 0 FIELD_OPTIONALLY_ENCLOSED_BY = '\042' TRIM_SPACE = FALSE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE ESCAPE = 'NONE' 
ESCAPE_UNENCLOSED_FIELD = '\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\N');

CREATE OR REPLACE STAGE AWS_MRF_STAGE   
url='s3://sara-sf-training/northwind/'
credentials=(aws_key_id='AKIA3ANSZTKRXPACT46V' aws_secret_key='9ALJwiSiYnXXQPflSAUfTKqSynh2NGGPEHRbI3hw');


LIST @AWS_MRF_STAGE;

COPY INTO CUSTOMER
FROM @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*customer.*[.]csv';

COPY INTO orders
FROM @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*orders.*[.]csv';

COPY INTO OrderItem
FROM @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*orderitem.*[.]csv'
FORCE = TRUE;

COPY INTO product
FROM @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*product.*[.]csv';

COPY INTO supplier
FROM @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*supplier.*[.]csv';






