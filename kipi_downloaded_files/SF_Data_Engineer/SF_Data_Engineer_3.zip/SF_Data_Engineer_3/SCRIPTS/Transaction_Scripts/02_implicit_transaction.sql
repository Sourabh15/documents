-- Implicit Transaction

ALTER SESSION SET AUTOCOMMIT = FALSE; 


CREATE OR REPLACE TABLE cust_account ( account_id varchar, balance number);
INSERT INTO cust_account(account_id,balance) values('ACCT_001',0.0);
CREATE OR REPLACE TABLE deposit_withdraw ( account_id varchar, amount number, transaction_type varchar, created_at TIMESTAMP_LTZ );

create or replace procedure return_greater(number_1 integer, number_2 integer)
returns integer not null
language sql
as
begin
  if (number_1 > number_2) then
    return number_1;
  else
    return number_2;
  end if;
end;


SET account_id = 'ACCT_001';
SET transaction_type = 'DEPOSIT';
SET amount = 200;
    

INSERT INTO deposit_withdraw (account_id,amount,transaction_type,created_at) 
VALUES($account_id ,$amount,$transaction_type,LOCALTIMESTAMP());

SELECT * FROM deposit_withdraw;

-- the below ddl commits the current transaction
CREATE or REPLACE TABLE temp (test varchar);

-- Call procedure

call return_greater(7,8);

--kill the session
select current_session();
SELECT SYSTEM$ABORT_SESSION(1263673868222486);


SELECT * FROM deposit_withdraw;

UPDATE cust_account 
SET balance = CASE $transaction_type
WHEN 'DEPOSIT' THEN balance + 'A'
--WHEN 'DEPOSIT' THEN balance + $amount
WHEN 'WITHDRAW' THEN balance - $amount
ELSE 0.00
END
WHERE account_id = $account_id ;

ROLLBACK;

SELECT * FROM deposit_withdraw;
SELECT * FROM temp;






