ALTER SESSION SET AUTOCOMMIT = FALSE; 

CREATE OR REPLACE TABLE cust_account ( account_id varchar, balance number);
INSERT INTO cust_account(account_id,balance) values('ACCT_001',0.0);
CREATE OR REPLACE TABLE deposit_withdraw ( account_id varchar, amount number, transaction_type varchar, created_at TIMESTAMP_LTZ );

BEGIN TRANSACTION;

SET account_id = 'ACCT_001';
SET transaction_type = 'DEPOSIT';
SET amount = 200;

INSERT INTO deposit_withdraw (account_id,amount,transaction_type,created_at) 
VALUES($account_id ,$amount,$transaction_type,LOCALTIMESTAMP());

-- it commits the existing transaction when it come across ddl stmt or call proc
CREATE OR REPLACE TABLE temp(test varchar);

UPDATE cust_account 
SET balance = CASE $transaction_type
--WHEN 'DEPOSIT' THEN balance + 'A'
WHEN 'DEPOSIT' THEN balance + $amount
WHEN 'WITHDRAW' THEN balance - $amount
ELSE 0.00
END
WHERE account_id = $account_id ;

--COMMIT
ROLLBACK;

SELECT * FROM cust_account;
SELECT * FROM deposit_withdraw;
SELECT * FROM TEMP;
