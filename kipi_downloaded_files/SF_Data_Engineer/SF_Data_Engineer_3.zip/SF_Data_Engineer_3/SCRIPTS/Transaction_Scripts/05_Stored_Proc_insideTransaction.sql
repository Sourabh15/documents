ALTER SESSION SET AUTOCOMMIT = FALSE; 


CREATE OR REPLACE TABLE cust_account ( account_id varchar, balance number);
INSERT INTO cust_account(account_id,balance) values('ACCT_001',0.0);
CREATE OR REPLACE TABLE deposit_withdraw ( account_id varchar, amount number, transaction_type varchar, created_at TIMESTAMP_LTZ );

---------------Transaction inside stored procedure with error -----------
CREATE OR REPLACE PROCEDURE do_deposit_withdraw(account_id varchar, amount number , transaction_type varchar )
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS owner
AS 
BEGIN
	let acct_balance := 0.00;
    
    SELECT balance INTO :acct_balance
    FROM cust_account
    WHERE account_id = :account_id;

    IF ((:acct_balance >= amount AND :transaction_type = 'WITHDRAW') OR (:transaction_type = 'DEPOSIT')) THEN 
    BEGIN
        
        INSERT INTO deposit_withdraw (account_id,amount,transaction_type,created_at) 
        VALUES(:account_id ,:amount,:transaction_type,LOCALTIMESTAMP());
    
        UPDATE cust_account 
        SET balance = CASE :transaction_type
        --WHEN 'DEPOSIT' THEN balance + 'A'
        WHEN 'DEPOSIT' THEN balance + :amount
        WHEN 'WITHDRAW' THEN balance - :amount
        ELSE 0.00
        END
        WHERE account_id = :account_id;
    END;
    END IF;
END;


SELECT * FROM cust_account;
SELECT * FROM deposit_withdraw;
BEGIN TRANSACTION;
CALL do_deposit_withdraw('ACCT_001',100.00,'DEPOSIT');
ROLLBACK;

SELECT * FROM cust_account;
SELECT * FROM deposit_withdraw;
