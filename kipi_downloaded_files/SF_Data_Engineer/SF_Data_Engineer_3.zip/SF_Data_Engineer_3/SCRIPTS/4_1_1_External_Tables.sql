-----------External Table --------------------
USE ROLE SYSADMIN;

CREATE OR REPLACE EXTERNAL TABLE EXT_CUSTOMERS_NOSCHEMA
WITH LOCATION = @AWS_MRF_STAGE
AUTO_REFRESH = true
FILE_FORMAT = 'MRF_CSV';

SELECT * FROM EXT_CUSTOMERS_NOSCHEMA;

CREATE OR REPLACE external table EXT_CUSTOMERS 
(ID INT as  (value:c1::int), 
FIRSTNAME varchar(20) as ( value:c2::varchar), 
LASTNAME varchar(20) as ( value:c3::varchar), 
CITY varchar(20) as ( value:c4::varchar), 
COUNTRY varchar(30) as ( value:c5::varchar)) 
WITH LOCATION = @AWS_MRF_STAGE
FILE_FORMAT = 'MRF_CSV'
pattern='.*customer.*[.]csv';

SELECT ID,FIRSTNAME,LASTNAME,CITY,COUNTRY,metadata$filename,METADATA$FILE_ROW_NUMBER FROM EXT_CUSTOMERS;

select distinct metadata$filename from @AWS_MRF_EXT_STAGE;



--External table with Partition
create or replace external table external_Orders (
   Year                 varchar AS split_part(metadata$filename,'/',2),
   Id                   number AS (value:c1::number),
   OrderNumber          varchar AS (value:c2::varchar),
   CustomerId           number AS (value:c1::number),
   TotalAmount          float AS (value:c1::float),
   OrderDate            varchar AS (value:c2::varchar)
)
PARTITION BY (Year)
LOCATION=@AWS_MRF_EXT_STAGE
AUTO_REFRESH = FALSE
PATTERN='.*order.*[.]csv'
FILE_FORMAT = (TYPE = CSV  SKIP_HEADER = 1) ;

select YEAR,Id,OrderNumber,CustomerId,TotalAmount,OrderDate from external_orders;

select distinct metadata$filename from @AWS_MRF_EXT_STAGE;

select * from external_orders where year='2014' limit 10;


-- when you added /removed files from s3 bucket then you need to manual refresh
alter external table external_Orders refresh;


-- Auto Refresh

create or replace external table external_Orders (
   Year                 varchar AS split_part(metadata$filename,'/',2),
   Id                   number AS (value:c1::number),
   OrderNumber          varchar AS (value:c2::varchar),
   CustomerId           number AS (value:c1::number),
   TotalAmount          float AS (value:c1::float),
   OrderDate            varchar AS (value:c2::varchar)
)
PARTITION BY (Year)
LOCATION=@AWS_MRF_EXT_STAGE
AUTO_REFRESH = TRUE
PATTERN='.*orders.*[.]csv'
FILE_FORMAT = (TYPE = CSV  SKIP_HEADER = 1) ;

SHOW EXTERNAL TABLES;

select distinct metadata$filename from @AWS_MRF_EXT_STAGE;

-- create stream

CREATE OR REPLACE STREAM EXT_ORDERS_STREAM ON EXTERNAL TABLE external_Orders INSERT_ONLY = TRUE;

SELECT * FROM EXT_ORDERS_STREAM;



