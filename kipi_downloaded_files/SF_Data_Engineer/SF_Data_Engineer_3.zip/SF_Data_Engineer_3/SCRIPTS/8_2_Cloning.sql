use role sysadmin;
use schema MRF_DB.SALES_SCHEMA;

-- Create a sample table
CREATE OR REPLACE TABLE EMPLOYEES
 (emp_id number,
 first_name varchar,
 last_name varchar
 );
 
 --DROP TABLE EMPLOYEES_CLONE;
-- Populate the table with some seed records.
Insert into EMPLOYEES
values(100,'John','Smith'),
 (200,'Sam','White'),
 (300,'Bob','Jones'),
 (400,'Linda','Carter');
-- Show the content of the table employees in the demo_db database and the public schema
select * from employees;
 
-- Create a clone of the table
CREATE OR REPLACE TABLE employees_clone
  CLONE employees;
  
 -- Show the content of the clone which should be the same as the original table that it was cloned from.
select * from employees_clone;
 
 -- Add one new record to the original employee table 
insert into employees
values(500,'George','Brown');


-- Check the content of the employees table. George Data is present
select * from employees;
 
-- Check the content of the employees_clone table. 
select * from employees_clone;
 
 
-- Add one more record to the clone table
insert into employees_clone values(600,'Mike','Jones');
 
-- Mike record is present
select * from employees_clone;
 
-- Verify the content of the original employees table.  
select * from employees;

-- Delete emp_id 100 from the employees table.
delete from employees where emp_id = 100;

-- Check the content of the employees table. emp_id 100 is missing
select * from employees;
 
-- Check the content of the employees_clone table.emp_id 100 still present in the table
select * from employees_clone;
 
  
--  Cloning Schema

-- Create a schema clone 
CREATE or replace schema  MRF_DB.HR_SCHEMA_BKUP CLONE MRF_DB.HR_SCHEMA;
 
-- Point to the schema clone
use schema MRF_DB.HR_SCHEMA_BKUP;
 
-- Drop the table employees from the schema_clone
drop table MRF_DB.HR_SCHEMA_BKUP.emp_basic;
 

 
