---------------------------------------------------------------------
-- Load json file 
---------------------------------------------------------------------
USE ROLE sysadmin;
USE SCHEMA MRF_DB.TRAINING_SCHEMA;

--Create an Ingestion Table for JSON Data
CREATE OR REPLACE TABLE AUTHOR_INGEST_JSON 
(
  "RAW_AUTHOR" VARIANT
);

--Create File Format for JSON DATA

CREATE OR REPLACE FILE FORMAT JSON_FILE_FORMAT 
TYPE = 'JSON' 
COMPRESSION = 'AUTO' 
ENABLE_OCTAL = FALSE 
ALLOW_DUPLICATE = FALSE 
STRIP_OUTER_ARRAY = TRUE 
STRIP_NULL_VALUES = FALSE 
IGNORE_UTF8_ERRORS = FALSE;

list @AWS_SEMISTRUCTURED_STAGE;

COPY INTO AUTHOR_INGEST_JSON FROM @AWS_SEMISTRUCTURED_STAGE
FILE_FORMAT = 'JSON_FILE_FORMAT'
pattern='.*author_with_header.*[.]json';

--returns entire record
SELECT raw_author 
FROM author_ingest_json;

--returns the data in a way that makes it look like a normalized table
SELECT 
 raw_author:AUTHOR_UID
,raw_author:FIRST_NAME::STRING AS FIRST_NAME
,raw_author:MIDDLE_NAME::STRING AS MIDDLE_NAME
,raw_author:LAST_NAME::STRING AS LAST_NAME
FROM AUTHOR_INGEST_JSON;
