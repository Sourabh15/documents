use role sysadmin;
use schema HR_SCHEMA;

create or replace masking policy email_mask as (val string) returns string ->
  case
    when current_role() in ('SYSADMIN') then val
    else '******'
  end;

alter table if exists emp_basic modify column email set masking policy email_mask;

select * from emp_basic;

