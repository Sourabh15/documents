--------------------------------------------------------
------------UNLOADING---------------------------------
---------------------------------------------------------
USE ROLE SYSADMIN;
USE SCHEMA MRF_DB.SALES_SCHEMA;

CREATE OR REPLACE FILE FORMAT mrf_csv_unload_format
TYPE = 'CSV'   field_delimiter = ',';

CREATE OR REPLACE STAGE mrf_unload_stage
FILE_FORMAT = mrf_csv_unload_format;

LIST @mrf_unload_stage;
  
COPY INTO @mrf_unload_stage/unload/customer FROM Customer;
  
LIST @mrf_unload_stage;
  
--GET @mrf_unload_stage/unload/customer_0_0_0.csv.gz file://c:\data\northwind\;

REMOVE @mrf_unload_stage;

-----------------------------------------------


CREATE OR REPLACE STAGE aws_customer_unload_stage 
URL = 's3://sara-sf-training/unload/' 
CREDENTIALS = (AWS_KEY_ID = 'AKIA3ANSZTKR55JOT4H5' 
               AWS_SECRET_KEY = 'nCEI/uu0IH807UvlCTaQVl211G3V56GUFJQVredv');

LIST @aws_customer_unload_stage;

REMOVE @aws_customer_unload_stage;

COPY INTO @aws_customer_unload_stage/customer.csv.gz 
FROM Customer
OVERWRITE = TRUE ;
