--You can use a cursor to iterate through query results one row at a time


-- Introduction to cursors

--To retrieve data from the results of a query, use a cursor. 
--You can use a cursor in loops to iterate over the rows in the results.
--To use a cursor, do the following:
--1) In the DECLARE section, declare the cursor.The declaration includes the query for the cursor.
--2) Execute the OPEN command to open the cursor. This executes the query and loads the results into the cursor.
--3) Execute the FETCH command to fetch one or more rows and process those rows.
--4) Execute the CLOSE command to close the cursor.

use schema demo_db.public;
create or replace table invoices (id integer, price number(12, 2));

insert into invoices (id, price) values
  (1, 11.11),
  (2, 22.22);


declare
  id integer default 0;
  minimum_price number(13,2) default 10.00;
  maximum_price number(13,2) default 20.00;
  c1 cursor for select id from invoices where price > ? and price < ?;
begin
  --open c1 using (minimum_price, maximum_price);
  open c1 using (minimum_price, maximum_price);
  fetch c1 into id;
  return id;
end;

---Returning a Table for a Cursor

declare
  c1 cursor for select * from invoices;
  id integer;
  price number(13,2);
begin
  open c1;
  fetch c1 into id, price;
  return table(resultset_from_cursor(c1));  
  close c1;
end;


-- Example of Using a Cursor

declare
    row_price float;
    total_price float;
    c1 cursor for select price from invoices;
begin
    row_price := 0.0;
    total_price := 0.0;
    open c1;
    fetch c1 into row_price;
    total_price := total_price + row_price;
    fetch c1 into row_price;
    total_price := total_price + row_price;
    close c1;
    return total_price;
end;



