use schema airbnb.public;
create or replace procedure output_message(message varchar)
returns varchar not null
language sql
as
begin
  return message;
end;

call output_message ('Hello world!');

----------------------
use airbnb.public;
create or replace procedure return_greater(number_1 integer, number_2 integer)
returns integer not null
language sql
as
begin
  if (number_1 > number_2) then
    return number_1;
  else
    return number_2;
  end if;
end;

call return_greater(1,2);

--Using an Argument in a SQL Statement (Binding)

create or replace procedure airbnb.public.find_invoice_by_id(id varchar)
returns table (id integer, name varchar)
language sql
as
declare
  res resultset default (select id,name from airbnb.raw.raw_hosts where id = :id);
begin
  return table(res);
end;

call airbnb.public.find_invoice_by_id(1581);

--Using an Argument as an Object Identifier

create or replace procedure airbnb.public.get_row_count(table_name varchar)
returns integer not null
language sql
as
declare
  row_count integer default 0;
  res resultset default (select count(*) as count from identifier(:table_name));
  c1 cursor for res;
begin
  for row_variable in c1 do
    row_count := row_variable.count;
  end for;
  return row_count;
end;

call airbnb.public.get_row_count('airbnb.raw.raw_hosts');
call airbnb.public.get_row_count('airbnb.raw.raw_listings');

---Using an Argument When Building a String for a SQL Statement

create or replace procedure airbnb.public.find_invoice_by_id_via_execute_immediate(id varchar)
returns table (id integer, name varchar)
language sql
as
declare
  select_statement varchar;
  res resultset;
begin
  select_statement := 'select id,name from airbnb.raw.raw_hosts where id = ' || id;
  res := (execute immediate :select_statement);
  return table(res);
end;

call airbnb.public.find_invoice_by_id_via_execute_immediate(1581);

