-- Within the DECLARE section of the block by using any of the following:

-- <variable_name> <type>;
-- <variable_name> DEFAULT <expression> ;
-- <variable_name> <type> DEFAULT <expression> ;

--- Within the BEGIN … END section of the block (before you use the variable) by using the LET command in any of the following ways:

-- LET <variable_name> <type> { DEFAULT | := } <expression> ;
-- LET <variable_name> { DEFAULT | := } <expression> ;

create database if not exists demo_db ;
drop table demo_db.public.customer;


create or replace table demo_db.public.customer (id integer, name varchar);
insert into demo_db.public.customer (id, name) values
    (1, 'Customer-1'),
    (2, 'Customer-2'),
    (3, 'Customer-3'),
    (4, 'Customer-4'),
    (5, 'Customer-5'),
    (6, 'Customer-6'),
    (7, 'Customer-7'),
    (8, 'Customer-8'),
    (9, 'Customer-9'),
    (10, 'Customer-10');


declare
    -- declaring variable with type and defaul tvalues
    profit number(38, 2) default 0.0;
    cost number(38, 2) default 100.0;
    revenue number(38, 2) default 110.0;
begin
    -- assigning values to the variable
    profit := revenue - cost;
    return profit;
end;
----------------------------------------------------------------------------------

--As mentioned earlier, when you declare a variable without explicitly
--specifying the data type, Snowflake Scripting infers the data type 
-- from the expression that you assign to the variable.

declare
    profit number(38, 2) default 0.0;
begin
    let cost := 100.0; -- declaring variable in the begin block with LET command
    let revenue := 110.0; -- infer the data type as FLOAT 
    profit := revenue - cost;
    return profit;
end;
-- Note:If Snowflake is unable to infer the intended data type, Snowflake reports a SQL compilation error.
----------------------------------------------------------------------------------------------

-- The example sets the Snowflake Scripting variables id and name to the 
-- values returned for the columns with those names.

declare
  id integer;
  name varchar;
begin
  
  select id, name into :id, :name 
  from demo_db.public.customer 
  where id = 2;

  return :id || ' ' || :name;
end;


--The following example shows how to declare a variable, assign a 
--value or expression to a variable, and cast a value to the 
--data type of a variable:

declare
  w integer;
  x integer default 0;
  dt date;
  result_string varchar;
begin
  w := 1;                     -- Assign a value.
  w := 24 * 7;                -- Assign the result of an expression.
  dt := '2020-09-30'::date;   -- Explicit cast.
  dt := '2020-09-30';         -- Implicit cast.
  result_string := w::varchar || ', ' || dt::varchar;
  return result_string;
end;

--The following example uses a built-in SQL function in the expression:

begin

let my_variable := sqrt(25);

return :my_variable ;

end