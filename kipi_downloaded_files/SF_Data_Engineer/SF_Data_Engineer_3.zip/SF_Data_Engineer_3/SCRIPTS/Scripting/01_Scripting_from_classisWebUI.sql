
-- Method -1 
set stmt =
$$
declare
    radius_of_circle float;
    area_of_circle float;
begin
    radius_of_circle := 3;
    area_of_circle := pi() * radius_of_circle * radius_of_circle;
    return area_of_circle;
end;
$$
;
execute immediate $stmt;


------------------------------
Method -2 
execute immediate $$
-- Snowflake Scripting code
declare
  radius_of_circle float;
  area_of_circle float;
begin
  radius_of_circle := 3;
  area_of_circle := pi() * radius_of_circle * radius_of_circle;
  return area_of_circle;
end;
$$
;

-----method -3 : create stored procedure
USE SCHEMA sales_schema;
create or replace procedure myprocedure()
  returns varchar
  language sql
  as
  $$
    -- Snowflake Scripting code
    declare
      radius_of_circle float;
      area_of_circle float;
    begin
      radius_of_circle := 3;
      area_of_circle := pi() * radius_of_circle * radius_of_circle;
      return area_of_circle;
    end;
  $$
  ;

  call myprocedure();