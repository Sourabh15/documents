/**
Snowflake Scripting raises an exception if an error occurs while executing 
a statement (e.g. if a statement attempts to DROP a table that doesn’t exist).
An exception prevents the next lines of code from executing.
In a Snowflake Scripting block, you can write exception handlers that catch specific types of exceptions declared in that block 
and in blocks nested inside that block.
In addition, for errors that can occur in your code, you can define your 
own exceptions that you can raise when errors occur.
**/

-- throw exception

declare
  my_exception exception (-20002, 'Raised MY_EXCEPTION.');
  counter number default 1;
begin
  let should_raise_exception := true;
  if (should_raise_exception) then
    raise my_exception;
  end if;
  counter := counter + 1;
  return counter;
end;

-------------

declare
    res resultset;
  my_exception exception (-20002, 'Raised MY_EXCEPTION.');
begin

  let should_raise_exception := false;
  if (should_raise_exception) then
    raise my_exception;
  end if;

  res := (select id,name from demo_db.public.customer order by name);
  return table(res);

exception
  when statement_error then
    return object_construct('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
  when my_exception then
    return object_construct('Error type', 'MY_EXCEPTION',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
  when other then
    return object_construct('Error type', 'Other error',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
end;