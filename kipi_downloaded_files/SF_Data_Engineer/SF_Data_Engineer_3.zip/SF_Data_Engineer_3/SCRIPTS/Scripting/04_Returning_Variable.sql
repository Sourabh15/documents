--To return a value, use the RETURN command. You can return a value from:

--A block in a stored procedure.
--An anonymous block.

-- returning sql Data Type using anonymous block
declare
    radius_of_circle float;
    area_of_circle float;
    -- declare cursors 
    -- declare exceptions
begin
    radius_of_circle := 3;
    area_of_circle := pi() * radius_of_circle * radius_of_circle;
    return area_of_circle;
end;

-- return a table using procedure
create or replace procedure sp_table_rtr(table_name varchar)
returns table()
language sql
as
  declare
    res resultset;
    query varchar;
  begin
    query := 'SELECT * FROM ' || :table_name || ' ORDER BY 1';
    res := (execute immediate :query);
    return table (res);
  end;
  
  call sp_table_rtr('snowflake_sample_data.tpch_sf1.customer');
  