-- Returning Tabular Data

create or replace procedure airbnb.public.get_raw_listings()
returns table (id integer, name varchar)
language sql
as
declare
  res resultset default (select id,name from airbnb.raw.raw_listings limit 10);
begin
  return table(res);
end;
-- call the proc
call airbnb.public.get_raw_listings()

/**
Calling a Stored Procedure From Another Stored Procedure
In a stored procedure, if you need to call another stored procedure,
use one of the following approaches:

1. Calling a Stored Procedure Without Using the Returned Value

2. Using the Value Returned From a Stored Procedure Call

**/

----Calling a Stored Procedure Without Using the Returned Value

create or replace table int_table (value integer);

create or replace procedure insert_value(value integer)
returns varchar not null
language sql
as
begin
  insert into int_table values (:value);
  return 'Rows inserted: ' || sqlrowcount;
end;

create or replace procedure insert_two_values(value1 integer, value2 integer)
returns varchar not null
language sql
as
begin
  call insert_value(:value1);
  call insert_value(:value2);
  return 'Finished calling stored procedures';
end;

-- call procedure and check table

call insert_two_values(4, 5);
select * from int_table;

----Using the Value Returned From a Stored Procedure Call

create or replace procedure count_greater_than(table_name varchar, maximum_count integer)
returns boolean not null
language sql
as
declare
  res1 resultset;
begin
  res1 := (call get_row_count(:table_name));
  let c1 cursor for res1;
  for row_variable in c1 do
    if (row_variable.get_row_count > maximum_count) then
      return true;
    else
      return false;
    end if;
 end for;
end;

--call count_greater_than('airbnb.raw.raw_hosts', 3000);

