/**In Snowflake Scripting, a RESULTSET is a SQL data type that points to the 
result set of a query.
Because a RESULTSET is just a pointer to the results, you must do one of the following 
to access the results through the RESULTSET:
        1) Use the TABLE() syntax to retrieve the results as a table.
        2) Iterate over the RESULTSET with a cursor.
**/

declare
  res resultset;
  col_name varchar;
  select_statement varchar;
begin
  col_name := 'name';
  select_statement := 'SELECT ' || col_name || ' FROM demo_db.public.some_data';
  res := (execute immediate :select_statement);
  return table(res);
end;

---Examples of Using a RESULTSET

create or replace procedure demo_db.public.sp_host_rtr()
returns table(id integer,name varchar)
language sql
as
  declare
    res resultset default (select id,name from demo_db.public.some_data order by name);
  begin
    return table(res);
  end;

-- execute the procedure
call demo_db.public.sp_host_rtr();

--  last query results
select * from table(result_scan(last_query_id())) order by 1;

--Example: Constructing the SQL Statement Dynamically

create or replace procedure demo_db.public.sp_host_rtr_dynamic(table_name varchar)
returns table(id integer,name varchar)
language sql
as
  declare
    res resultset;
    query varchar default 'SELECT id,name FROM ' || :table_name || ' ORDER BY name';
  begin
    res := (execute immediate :query);
    return table (res);
  end;

  -- execute the procedure
call demo_db.public.sp_host_rtr_dynamic('some_data');




--Example: Declaring a RESULSET Variable Without a DEFAULT Clause

create or replace procedure demo_db.public.sp_host_rtr_NoDefault()
returns table(id integer, name varchar)
language sql
as
  declare 
    res resultset;
  begin
    res := (select id,name from demo_db.public.some_data order by name);
    return table(res);
  end;

  -- execute procedure
  call demo_db.public.sp_host_rtr_NoDefault();

  ----Example: Using a CURSOR With a RESULTSET-----

create or replace procedure demo_db.public.sp_host_rtr_UsingCursor()
returns varchar
language sql
as

  declare
    accumulator varchar default 0;
    res1 resultset default (select id from demo_db.public.customer limit 10);
    cur1 cursor for res1;
  begin
    for row_variable in cur1 do
        accumulator := accumulator + row_variable.id;
    end for;
    return accumulator;
  end;

call demo_db.public.sp_host_rtr_UsingCursor();

----


declare
  result varchar;
  exception_1 exception (-20001, 'I caught the expected exception.');
  exception_2 exception (-20002, 'Not the expected exception!');
begin
  result := 'If you see this, I did not catch any exception.';
  if (true) then
    raise exception_1;
  end if;
  return result;
  
exception
  when exception_2 then
    return sqlerrm;
  when exception_1 then
    return sqlerrm;
end;