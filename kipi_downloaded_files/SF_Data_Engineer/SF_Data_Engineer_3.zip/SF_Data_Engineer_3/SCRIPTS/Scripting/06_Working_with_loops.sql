-- A FOR loop repeats a sequence of steps for a specified number of times or for each row in a result set. Snowflake Scripting supports the following types of FOR loops:
-- 1. Counter-Based FOR Loops
-- 2. Cursor-Based FOR Loops

--Counter-Based FOR Loops
declare
  counter integer default 0;
  maximum_count integer default 5;
begin
  for i in 1 to maximum_count do
    counter := counter + 1;
  end for;
  return counter;
end;

-- Cursor-Based FOR Loops


-- The following example uses a FOR loop iterate over the rows in a cursor for the invoices table:
use schema demo_db.public;
create or replace table invoices (price number(12, 2));
insert into invoices (price) values
  (11.11),
  (22.22);

declare
  total_price float;
  c1 cursor for select price from invoices;
begin
  total_price := 0.0;
  for record in c1 do
    total_price := total_price + record.price;
  end for;
  return total_price;
end;


---While Loop---

--A WHILE loop iterates while a condition is true. In a WHILE loop, 
--the condition is tested immediately before executing the body of the 
--loop. If the condition is false before the first iteration, then the 
--body of the loop does not execute even once.

begin
  let counter := 0;
  while (counter < 5) do
    counter := counter + 1;
  end while;
  return counter;
end;

--- Repeat loop

--A REPEAT loop iterates until a condition is true. 
--In a REPEAT loop, the condition is tested immediately after 
--executing the body of the loop. As a result, the body of the loop 
--always executes at least once.

begin
  let counter := 5;
  let number_of_iterations := 0;
  repeat
    counter := counter - 1;
    number_of_iterations := number_of_iterations + 1;
  until (counter = 0)
  end repeat;
  return number_of_iterations;
end;


--- Break Statement --

--A LOOP loop executes until a BREAK command is executed.

begin
  let counter := 5;
  loop
    if (counter = 0) then
      break;
    end if;
    counter := counter - 1;
  end loop;
  return counter;
end;

--The following example demonstrates this in a nested loop:

begin
  let inner_counter := 0;
  let outer_counter := 0;
  loop
    loop
      if (inner_counter < 5) then
        inner_counter := inner_counter + 1;
        continue outer;
      else
        break outer;
      end if;
    end loop inner;
    outer_counter := outer_counter + 1;
    break;
  end loop outer;
  return array_construct(outer_counter, inner_counter);
end;


