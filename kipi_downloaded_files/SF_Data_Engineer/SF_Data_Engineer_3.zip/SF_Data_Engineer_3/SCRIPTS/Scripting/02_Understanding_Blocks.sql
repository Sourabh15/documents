
--DECLARE
--... (variable declarations, cursor declarations, etc.) ...
--BEGIN
-- ... (Snowflake Scripting and SQL statements) ...
--EXCEPTION
--... (statements for handling exceptions) ...
--END;

--If the code uses variables, 
--you can declare those variables in the block. 

declare
    radius_of_circle float;
    area_of_circle float;
    -- declare cursors 
    -- declare exceptions
begin
    radius_of_circle := 3;
    area_of_circle := pi() * radius_of_circle * radius_of_circle;
    return area_of_circle;
end;

---Using a Block in a Stored Procedure

create or replace procedure areaOfCircle()
  returns float
  language sql
  as
    declare
      radius float;
      area_of_circle float;
    begin
      radius := 3;
      area_of_circle := pi() * radius * radius;
      return area_of_circle;
    end;



